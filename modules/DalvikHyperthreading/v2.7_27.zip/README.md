# DalvikHyperthreading

![](https://i.ibb.co/C2WZsJk/1648364568480.png)

## Description
This does is helps the multithread line to tell the cpu to easily do more faster proccessing without overheating.

Esto ayuda a la línea multiproceso a decirle a la CPU que realice fácilmente un procesamiento más rápido sin sobrecalentamiento.

"Multithreading or multi-core dexopt"

## Installation 
1. Flash the module in Magisk
3. Reboot
4. Enjoy!

## Changelog
• [v1 - Initial release - 12-03-22 ](https://t.me/modulostk/665)

• v2 - Update Template v2 for magisk 24 - 14-01-23

## Support
• [GitHub](https://github.com/LeanxModulostk/DalvikHyperthreading) 
• [Telegram Channel](https://t.me/modulostk)

## Special Thanks

• [g7755725](https://forum.xda-developers.com/t/fps-ipv4-6-build-prop-tweaks.3166013/)

• [Zackptg5](https://github.com/Zackptg5) for the MMT-Ex template

• [Topjohnwu](https://github.com/topjohnwu) for making Magisk