
find $MODPATH/ -type f -name 'data_restore*' -exec cp  {} /sdcard/ \;
