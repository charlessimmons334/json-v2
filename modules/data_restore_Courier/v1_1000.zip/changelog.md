2.14  
• Some fixes for TWRP restoring  

2.13  
• Added support of some Xiaomi  
• Fixes  

2.12  
• Fixes  
• Added support of  
~ Poco M5, Android 12 miui w/o TWRP  
~ Realme 6pro, Android 12 w/o TWRP / with Orangefox   
~ Tecno Camon 19 Neo, Android 12 w/o TWRP  

2.11  
• Initial release
